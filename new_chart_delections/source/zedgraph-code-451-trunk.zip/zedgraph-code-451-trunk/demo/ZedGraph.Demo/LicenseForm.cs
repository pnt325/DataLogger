using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ZedGraph.Demo
{
	public partial class LicenseForm : Form
	{
		public LicenseForm()
		{
			InitializeComponent();
		}
	}
}