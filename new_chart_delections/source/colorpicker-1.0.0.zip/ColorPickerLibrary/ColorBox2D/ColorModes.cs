﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MechanikaDesign.WinForms.UI.ColorPicker
{
    public enum ColorModes
    {
        Red,
        Green,
        Blue,
        Hue,
        Saturation,
        Luminance
    }

}
