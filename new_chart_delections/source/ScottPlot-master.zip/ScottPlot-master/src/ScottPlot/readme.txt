
Learn how to use ScottPlot by reviewing these webpages...

Quickstart:
https://github.com/swharden/ScottPlot#quickstart

Cookbook:
https://github.com/swharden/ScottPlot/tree/master/doc/cookbook

ScottPlot API:
https://github.com/swharden/ScottPlot/tree/master/doc
